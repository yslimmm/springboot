package com.sist.hr.service;

import com.sist.hr.domain.MemberVO;

public interface MemberSvc {

	MemberVO do_selectOne(MemberVO vo);

}