package com.sist.hr.user.controller;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.sist.hr.user.domain.User;
import com.sist.hr.user.service.UserSvc;

@Controller
public class UserController {

	private final Logger log = LoggerFactory.getLogger(UserController.class);
	@Autowired
	private UserSvc userSvc;
	private final String RETURN_URL = "user/user";
	
	
	
	@RequestMapping(value="user/search.do")
	public String do_search(User user,Model model) throws ClassNotFoundException, SQLException{
		log.info("1++++++++++++++++++++++++++++");
		log.info("1+user+"+user);
		
		//page_size=0, page_num=0, search_div=null, search_word=null
		if(user.getPage_size()==0) {
			user.setPage_size(1);
		}
		
		if(user.getPage_num()==0) {
			user.setPage_num(10);
		}
		
		if(null == user.getSearch_div()) {
			user.setSearch_div("");
		}
		
		if(null == user.getSearch_word()) {
			user.setSearch_word("");
		}
		
		log.info("1.1+user+"+user);
		
		model.addAttribute("param", user);
		model.addAttribute("list", userSvc.do_retrieve(user));
		
		return RETURN_URL;
	}
	   
	//delete.do
	@RequestMapping(value="user/delete.do"  
			,method=RequestMethod.POST
			,produces="application/json;charset=UTF-8")
	@ResponseBody
	public String  delete(HttpServletRequest req,Model model) throws ClassNotFoundException, SQLException{
		String uIdList = req.getParameter("u_id_list");
		log.info("uIdList+"+uIdList);
		
		Gson gson=new Gson();
		List<String> listParam=gson.fromJson(uIdList, List.class);
		log.info("listParam+"+listParam);
		
		List<User> paramList=new ArrayList<User>();
		for(int i=0;i<listParam.size();i++) {
			User vo=new User();
			vo.setU_id(listParam.get(i));
			paramList.add(vo);
		}
		
		int flag = this.userSvc.do_delmulti(paramList);
		
		JSONObject object = new JSONObject();
		if(flag>0) {
			object.put("message", "삭제 성공");
		} else {
			object.put("message", "삭제 실패");
		}
		
		String jsonData = object.toJSONString();
		
		return jsonData;
	}	  
	//
	@RequestMapping(value="user/update.do"
			,method=RequestMethod.POST
			,produces="application/json;charset=UTF-8")
	@ResponseBody
	public String  update(User user,HttpServletRequest req,Model model) throws ClassNotFoundException, SQLException{
		String upsert_div = req.getParameter("upsert_div");
		log.info("1++++++++++++++++++++++++++++");
		log.info("1+user+"+user);  
		log.info("1+upsert_div+"+upsert_div);  
		log.info("1++++++++++++++++++++++++++++");
		     
		int flag = 0;
		
		if("update".equals(upsert_div)) {
			flag = this.userSvc.update(user);
		}else {
			flag = this.userSvc.add(user);
		}
		
		JSONObject  object=new JSONObject();
		object.put("flag", flag);
		
		if(flag>0) {
			object.put("message", "등록 되었습니다.");
		}else {
			object.put("message", "등록 실패.");
		} 
		
		String jsonData = object.toJSONString();  
		
		log.info("1++++++++++++++++++++++++++++");
		log.info("1+jsonData+"+jsonData);  
		log.info("1++++++++++++++++++++++++++++");		
		return jsonData;
	}
	
		
	
	@RequestMapping(value="user/do_search_one.do"
			,method=RequestMethod.GET
			,produces="application/json;charset=UTF-8")
	@ResponseBody
	public User  get(User user,Model model) throws ClassNotFoundException, SQLException{
		log.info("1++++++++++++++++++++++++++++");
		log.info("1+user+"+user);  
		log.info("1++++++++++++++++++++++++++++");
		User outVO = userSvc.get(user.getU_id());
		log.info("1.1++++++++++++++++++++++++++++");
		log.info("1.1+outVO+"+outVO);
		log.info("1.1.++++++++++++++++++++++++++++");
		
		return outVO;
	}
	
	@RequestMapping(value="user/do_sel.do",method=RequestMethod.POST)
	public String del(User user,Model model) throws ClassNotFoundException, SQLException{
		log.debug("1++++++++++++++++++++++++++++");
		log.debug("1+user+"+user);
		log.debug("1++++++++++++++++++++++++++++");
		
		int flag = userSvc.del(user.getU_id());
		
		log.debug("1.1++++++++++++++++++++++++++++");
		log.debug("1.1+flag+"+flag);
		log.debug("1.1.++++++++++++++++++++++++++++");		
		return RETURN_URL;
	}
	
}
