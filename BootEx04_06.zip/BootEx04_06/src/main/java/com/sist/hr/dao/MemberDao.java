package com.sist.hr.dao;

import com.sist.hr.domain.MemberVO;

public interface MemberDao {

	MemberVO do_selectOne(MemberVO vo);

}