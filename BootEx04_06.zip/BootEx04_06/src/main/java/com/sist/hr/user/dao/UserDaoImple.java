package com.sist.hr.user.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.sist.hr.user.domain.Level;
import com.sist.hr.user.domain.User;



@Repository
public class UserDaoImple implements UserDao {
	private static Logger log = LoggerFactory.getLogger(UserDaoImple.class);
	
	//전체 삭제,등록
	@Autowired
    private JdbcTemplate jdbcTemplate;
    
	private RowMapper<User> userMapper = 
			new RowMapper<User>() {
				public User mapRow(ResultSet rs, int rowNum) throws SQLException {
					User user = new User();
					user.setU_id(rs.getString("u_id"));
					user.setName(rs.getString("name"));
					user.setPassword(rs.getString("password"));
					
					user.sethLevel(Level.valueOf(rs.getInt("h_level")));
					user.setLogin(rs.getInt("login"));
					user.setRecommend(rs.getInt("recommend"));
					user.setEmail(rs.getString("email"));
					user.setRegDt(rs.getString("reg_dt"));
					
					user.setNo(rs.getInt("rnum"));
					user.setTotal_cnt(rs.getInt("total_cnt"));
					return user;
				}
    };
	

    
    
    
	/* (non-Javadoc)
	 * @see com.sist.hr.user.dao.UserDao#getCount(java.lang.String)
	 */
	@Override
	public int getCount(String user_id)throws ClassNotFoundException,SQLException{
		
		
		int cnt = 0;
		
		//--------------------------------------------		
		//query
		//--------------------------------------------
		StringBuilder sb=new StringBuilder();		
		sb.append(" SELECT            \n");
		sb.append("     count(*) cnt  \n");
		sb.append(" FROM users        \n");
		sb.append(" WHERE u_id LIKE ? \n");
		log.info("sql:\n"+sb.toString());
		//--------------------------------------------		
		//실행
		//--------------------------------------------
		log.info("param:\n"+user_id);
		return this.jdbcTemplate.queryForObject(sb.toString()
				,new Object[] {"%"+user_id+"%"}
		        ,Integer.class);
	}
	
	
	
	/* (non-Javadoc)
	 * @see com.sist.hr.UserDao#delAll()
	 */
	/* (non-Javadoc)
	 * @see com.sist.hr.user.dao.UserDao#delAll()
	 */
	@Override
	public void delAll()throws SQLException, ClassNotFoundException{
		jdbcTemplate.update("DELETE FROM users");
	}
	
	/* (non-Javadoc)
	 * @see com.sist.hr.UserDao#del(java.lang.String)
	 */
	/* (non-Javadoc)
	 * @see com.sist.hr.user.dao.UserDao#del(java.lang.String)
	 */
	@Override
	public int del(String user_id)throws ClassNotFoundException,SQLException{
		
		//--------------------------------------------		
		//query
		//--------------------------------------------
		StringBuilder sb=new StringBuilder();
		sb.append(" DELETE FROM users WHERE u_id=? \n");
		log.info("sql:\n"+sb.toString());
		log.info("param:\n"+user_id);
		//--------------------------------------------		
		//실행
		//--------------------------------------------		
		Object[] args = {user_id};
		
		return this.jdbcTemplate.update(sb.toString(), args);
	}
	
	/* (non-Javadoc)
	 * @see com.sist.hr.UserDao#getAll()
	 */
	/* (non-Javadoc)
	 * @see com.sist.hr.user.dao.UserDao#getAll()
	 */
	@Override
	public List<User> getAll()throws ClassNotFoundException,SQLException{
		//--------------------------------------------		
		//query
		//--------------------------------------------
		StringBuilder  sb=new StringBuilder();
		sb.append(" SELECT                                     \n");
		sb.append("     u_id,                                  \n");
		sb.append("     name,                                  \n");
		sb.append("     password,                              \n");
		sb.append("     h_level,                               \n");
		sb.append("     login,                                 \n");
		sb.append("     recommend,                             \n");
		sb.append("     email,                                 \n");
		sb.append("     TO_CHAR(reg_dt,'YYYY-MM-DD') as reg_dt, \n");
		sb.append("     1 rnum  ,                              \n");
		sb.append("     1 total_cnt                            \n");		
		sb.append(" FROM users                                 \n");
		sb.append(" ORDER BY  u_id                             \n"); 
		log.info("sql:\n"+sb.toString());
		return this.jdbcTemplate.query(sb.toString()
				,  userMapper);
	}
	
	/* (non-Javadoc)
	 * @see com.sist.hr.UserDao#get(java.lang.String)
	 */
	/* (non-Javadoc)
	 * @see com.sist.hr.user.dao.UserDao#get(java.lang.String)
	 */
	@Override
	public User get(String user_id)
			throws ClassNotFoundException,SQLException,EmptyResultDataAccessException{
		//--------------------------------------------		
		//query
		//--------------------------------------------
		StringBuilder  sb=new StringBuilder();
		sb.append(" SELECT                                     \n");
		sb.append("     u_id,                                  \n");
		sb.append("     name,                                  \n");
		sb.append("     password,                              \n");
		sb.append("     h_level,                               \n");
		sb.append("     login,                                 \n");
		sb.append("     recommend,                             \n");
		sb.append("     email,                                 \n");
		sb.append("     TO_CHAR(reg_dt,'YYYY-MM-DD') as reg_dt,\n");
		sb.append("     1 rnum  ,                              \n");
		sb.append("     1 total_cnt                            \n");
		sb.append(" FROM users                                 \n");
		sb.append(" WHERE u_id = ?                             \n");
		log.info("sql:\n"+sb.toString());
		log.info("user_id:"+user_id);
		return this.jdbcTemplate.queryForObject(sb.toString()
				, new Object[] {user_id}
		        , userMapper
		      );
		
	}

	/* (non-Javadoc)
	 * @see com.sist.hr.UserDao#add(com.sist.hr.User)
	 */
	/* (non-Javadoc)
	 * @see com.sist.hr.user.dao.UserDao#add(com.sist.hr.user.domain.User)
	 */
	@Override
	public int add(final User user)throws ClassNotFoundException,SQLException{
		StringBuilder sb=new StringBuilder();
		sb.append(" INSERT INTO users ( \n");
		sb.append("     u_id,           \n");
		sb.append("     name,           \n");
		sb.append("     password,       \n");
		sb.append("     h_level,        \n");
		sb.append("     login,          \n");
		sb.append("     recommend,      \n");
		sb.append("     email,          \n");
		sb.append("     reg_dt          \n");
		sb.append(" ) VALUES (          \n");
		sb.append("     ?,              \n");
		sb.append("     ?,              \n");
		sb.append("     ?,              \n");
		sb.append("     ?,              \n");
		sb.append("     ?,              \n");
		sb.append("     ?,              \n");
		sb.append("     ?,              \n");
		sb.append("     sysdate         \n");
		sb.append(" )                   \n");
		log.info("sql:\n"+sb.toString());
		Object[] args = {user.getU_id()
				,user.getName()
				,user.getPassword()
				,user.gethLevel().intValue()
				,user.getLogin()
				,user.getRecommend()
				,user.getEmail()};
		
		return jdbcTemplate.update(sb.toString(),args );

	}

	/* (non-Javadoc)
	 * @see com.sist.hr.user.dao.UserDao#update(com.sist.hr.user.domain.User)
	 */
	@Override
	public int update(User user) throws SQLException {
		StringBuilder sb=new StringBuilder();
		sb.append(" UPDATE users              \n");
		sb.append(" SET  name      = ?        \n");
		sb.append("     ,password  = ?        \n");
		sb.append("     ,h_level   = ?        \n");
		sb.append("     ,login     = ?        \n");
		sb.append("     ,recommend = ?        \n");
		sb.append("     ,email     = ?        \n");
		sb.append("     ,reg_dt    = sysdate  \n");
		sb.append(" WHERE u_id     = ?        \n");
		
		log.info("sql:\n"+sb.toString());
		Object[] args = {user.getName()
				,user.getPassword()
				,user.gethLevel().intValue()
				,user.getLogin()
				,user.getRecommend()
				,user.getEmail()
				,user.getU_id()
				};
		log.info("param:\n"+user);
			
		return jdbcTemplate.update(sb.toString(),args );	
	}



	@Override
	public List<User> do_retrieve(User user) throws SQLException {
		List<User> list =new ArrayList<User>();
		//search query
		StringBuilder param=new StringBuilder();
		if(null !=user && !"".equals(user.getSearch_div())) {
			
			if("10".equals(user.getSearch_div())) {
				param.append("where hr.u_id like ?||'%' \n");
			}else if("10".equals(user.getSearch_div())) {
				param.append("where hr.name like ?||'%' \n");
			}
		}else {
			
		}
		
		//main query
		StringBuilder sb=new StringBuilder();
		sb.append(" SELECT  T.u_id,                                              \n");
		sb.append(" 		T.name,                                              \n");
		sb.append(" 		T.password,                                          \n");
		sb.append(" 		T.h_level,                                           \n");
		sb.append(" 		T.login,                                             \n");
		sb.append(" 		T.recommend,                                         \n");
		sb.append(" 		T.email,                                             \n");
		sb.append(" 		TO_CHAR(T.reg_dt,'YYYY-MM-DD') reg_dt,               \n");
		sb.append(" 		T.total_cnt,                                         \n");
		sb.append(" 		T.rnum                                               \n");
		sb.append("   FROM(                                                      \n");
		sb.append(" 	SELECT hr.*                                              \n");
		sb.append(" 		  ,ROW_NUMBER() OVER(ORDER BY reg_dt DESC) AS rnum   \n");
		sb.append(" 		  ,COUNT(*) OVER() AS total_cnt                      \n");
		sb.append(" 	  FROM users hr                                       \n");
		//--검색------------------------------------------------------------
		sb.append( param.toString());
		//--//검색------------------------------------------------------------		
		sb.append("                                                              \n");
		sb.append("   ) T                                                        \n");
		sb.append("   WHERE rnum BETWEEN (? * (?-1)+1 )                          \n");
		sb.append("     AND (? * (?-1)+?)                                        \n");
		
		log.info("1. sql:\n"+sb.toString());
		
		//sb.append("   WHERE rnum BETWEEN (:PAGE_SIZE * (:PAGE_NUM-1)+1 )         \n");
		//sb.append("     AND (:PAGE_SIZE * (:PAGE_NUM-1)+:PAGE_SIZE)              \n");
		List<Object> listArgs = new ArrayList<Object>();
		if(null !=user && !"".equals(user.getSearch_div())) {
			listArgs.add(user.getSearch_word());
			listArgs.add(user.getPage_size());
			listArgs.add(user.getPage_num());
			listArgs.add(user.getPage_size());
			listArgs.add(user.getPage_num());
			listArgs.add(user.getPage_size());
		}else {
			listArgs.add(user.getPage_size());
			listArgs.add(user.getPage_num());
			listArgs.add(user.getPage_size());
			listArgs.add(user.getPage_num());
			listArgs.add(user.getPage_size());			
		}
		list = this.jdbcTemplate.query(sb.toString()
				, listArgs.toArray()
				, this.userMapper);
		log.info("2. list:\n"+list);
		return list;
	}

}
