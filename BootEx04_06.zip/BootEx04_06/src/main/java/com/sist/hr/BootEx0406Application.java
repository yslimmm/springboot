package com.sist.hr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootEx0406Application {

	public static void main(String[] args) {
		SpringApplication.run(BootEx0406Application.class, args);
	}
}
